package com.misprimerasempresas.contenido;

public class contenido {

    public static String getInicio() {
        return "<div class='container my-5 text-center'><h1 class='display-4 text-primary'>Bienvenido a HelpDrom</h1>"
                + "<p class='lead'>En HelpDrom, llevamos la tecnología al siguiente nivel...</p>"
                + "<ul class='list-group list-group-flush'>"
                + "  <li class='list-group-item'>Tratamiento fitosanitario de precisión</li>"
                + "  <li class='list-group-item'>Levantamientos topográficos exactos</li>"
                + "  <li class='list-group-item'>Ahuyento de aves</li>"
                + "  <li class='list-group-item'>Inspección de aerogeneradores y placas solares</li>"
                + "  <li class='list-group-item'>Producción de videos y fotos profesionales</li>"
                + "</ul></div>";
    }

public static String getSobreNosotros() {
    return "<div class='container my-5 text-center'><h1>Sobre Nosotros</h1>"
            + "<p class='parrafo-recuadro parrafo-recuadro-gris'>Con más de 10 años de experiencia en tecnología de drones, HelpDrom es líder en soluciones aéreas avanzadas que transforman industrias, desde la agricultura hasta la energía renovable.</p>"
            + "<p class='parrafo-recuadro parrafo-recuadro-blanco'><strong>Visión:</strong> Ser líderes en tecnología aérea, comprometidos con la sostenibilidad y la innovación para mejorar el futuro.</p>"
            + "<p class='parrafo-recuadro parrafo-recuadro-gris'><strong>Misión:</strong> Aportar soluciones de alta precisión, sostenibles y personalizadas para maximizar el rendimiento y seguridad de nuestros clientes.</p></div>";
}


    public static String getServicios() {
        return "<div class='container my-5 text-center'><h1>Nuestros Servicios</h1><ul class='list-group'>"
                + "<li class='list-group-item'>Tratamiento fitosanitario de precisión - $500<br><small>Aplicación de productos de manera controlada para una protección eficaz y ecológica de los cultivos.</small></li>"
                + "<li class='list-group-item'>Levantamientos topográficos exactos - $1000<br><small>Datos detallados y precisos para proyectos de construcción, minería y planificación territorial.</small></li>"
                + "<li class='list-group-item'>Ahuyentamiento de aves - $700<br><small>Protección de cultivos y áreas sensibles mediante técnicas de disuasión con drones.</small></li>"
                + "<li class='list-group-item'>Inspección de aerogeneradores - $800<br><small>Evaluación de aerogeneradores y paneles solares para un mantenimiento seguro y eficiente.</small></li>"
                + "<li class='list-group-item'>Producción de videos y fotos profesionales - $1200<br><small>Captura de imágenes de alta calidad para promoción de propiedades, eventos y más.</small></li>"
                + "</ul></div>";
    }

    public static String getTestimonio() {
        return "<div class='container my-5 text-center'><h1>Testimonios de Clientes</h1>"
                + "<blockquote class='blockquote'><p>El servicio fue excelente y cumplió con todas nuestras expectativas en precisión y rapidez.</p><footer class='blockquote-footer'>Juan Pérez, Ingeniero Civil</footer></blockquote>"
                + "<blockquote class='blockquote'><p>Gracias a sus servicios, logramos una mayor eficiencia en nuestras operaciones agrícolas, con un impacto positivo en el rendimiento de las cosechas.</p><footer class='blockquote-footer'>Ana García, Productora Agrícola</footer></blockquote>"
                + "<blockquote class='blockquote'><p>La inspección de aerogeneradores fue precisa y nos ayudó a planificar mejor nuestro mantenimiento preventivo.</p><footer class='blockquote-footer'>Carlos Díaz, Jefe de Mantenimiento en Energía Renovable</footer></blockquote></div>";
    }

public static String getGaleria() {
    return "<div class='container my-5 text-center'>"
            + "<h1>Galería</h1>"
            + "<p>Explora algunos de nuestros proyectos recientes y observa cómo HelpDrom transforma industrias con drones de última tecnología.</p>"
            + "<style>"
            + ".imagen-pequena { width: 200px; height: 200px; object-fit: cover; }" // Estilos para hacer las imágenes pequeñas
            + "</style>"
            + "<div class='row'>"
            + "<div class='col-md-6'><img src='Imagen1.jpg' class='img-fluid rounded imagen-pequena' alt='Dron realizando levantamiento topográfico'></div>"
            + "<div class='col-md-6'><img src='Imagen2.jpg' class='img-fluid rounded imagen-pequena' alt='Inspección de aerogenerador'></div>"
            + "</div></div>";
}

    public static String getContacto() {
        return "<div class='container my-5 text-center'><h1>Contacto</h1>"
                + "<p>Puedes contactarnos a través del siguiente formulario o comunicarte directamente a través de los siguientes medios:</p>"
                + "<p><strong>Teléfono:</strong> +34 123 456 789</p>"
                + "<p><strong>Email:</strong> info@helpdrom.com</p>"
                + "<p><strong>Dirección:</strong> Calle de la Innovación, 42, Madrid, España</p>"
                + "<p><em>Nuestro horario de atención es de lunes a viernes de 9:00 a 18:00.</em></p>"
                + "<form>"
                + "  <div class='form-group'><label for='nombre'>Nombre:</label><input type='text' id='nombre' name='nombre' class='form-control'></div>"
                + "  <div class='form-group'><label for='email'>Email:</label><input type='email' id='email' name='email' class='form-control'></div>"
                + "  <div class='form-group'><label for='mensaje'>Mensaje:</label><textarea id='mensaje' name='mensaje' class='form-control'></textarea></div>"
                + "  <button type='submit' class='btn btn-primary mt-3'>Enviar</button>"
                + "</form>"
                + "<p class='mt-4'>¡Estamos aquí para ayudarte! Si tienes dudas o necesitas más información sobre alguno de nuestros servicios, no dudes en escribirnos.</p></div>";
    }

    public static String getFAQ() {
        return "<div class='container my-5 text-center'><h1>Preguntas Frecuentes (FAQ)</h1>"
                + "<h5>¿Qué tipo de servicios ofrecen?</h5><p>Ofrecemos servicios como levantamientos topográficos, tratamientos agrícolas de precisión, inspecciones de estructuras como aerogeneradores y producción de material audiovisual profesional.</p>"
                + "<h5>¿En qué áreas trabajan?</h5><p>Nuestros servicios están disponibles tanto a nivel nacional como internacional, adaptándonos a las necesidades del cliente.</p>"
                + "<h5>¿Qué tipo de drones utilizan?</h5><p>Contamos con drones de última tecnología, equipados para diversas aplicaciones, desde cámaras de alta resolución hasta sensores especializados para aplicaciones agrícolas.</p>"
                + "<h5>¿Cuánto tiempo se tarda en recibir el servicio?</h5><p>El tiempo varía según el proyecto, pero siempre trabajamos para ofrecer resultados en el menor tiempo posible, sin comprometer la calidad.</p></div>";
    }

    public static String getPrivacidad() {
        return "<div class='container my-5 text-center'><h1>Política de Privacidad</h1>"
                + "<p>En HelpDrom, respetamos la privacidad de nuestros usuarios y estamos comprometidos con la protección de sus datos personales. Esta política describe cómo recopilamos, utilizamos y protegemos tu información personal.</p>"
                + "<p><strong>Recopilación de Información:</strong> Solo recopilamos los datos necesarios para ofrecerte nuestros servicios, como tu nombre, correo electrónico y número de contacto.</p>"
                + "<p><strong>Uso de la Información:</strong> Utilizamos tu información para responder a tus consultas, procesar tus solicitudes y mejorar nuestros servicios. Nunca compartiremos tus datos con terceros sin tu consentimiento explícito.</p>"
                + "<p><strong>Protección de Datos:</strong> Implementamos medidas de seguridad adecuadas para proteger tu información contra accesos no autorizados.</p>"
                + "<p>Si tienes alguna pregunta sobre nuestra política de privacidad o deseas ejercer tus derechos de acceso, rectificación o eliminación, por favor contáctanos a <a href='mailto:privacidad@helpdrom.com'>privacidad@helpdrom.com</a>.</p></div>";
    }

    public static String getTerminos() {
        return "<div class='container my-5 text-center'><h1>Términos y Condiciones</h1>"
                + "<p>Al utilizar el sitio web de HelpDrom y nuestros servicios, aceptas estos términos y condiciones. Te recomendamos leerlos detenidamente para entender tus derechos y responsabilidades.</p>"
                + "<p><strong>Condiciones de Uso:</strong> Este sitio web y su contenido son propiedad de HelpDrom. Está prohibida la reproducción, distribución o uso comercial sin nuestro consentimiento explícito.</p>"
                + "<p><strong>Responsabilidad del Usuario:</strong> Al utilizar nuestros servicios, el usuario se compromete a proporcionar información veraz y a no realizar actividades ilegales o fraudulentas a través de nuestro sitio.</p>"
                + "<p><strong>Servicios:</strong> HelpDrom se compromete a ofrecer servicios de alta calidad. Sin embargo, no nos hacemos responsables de daños causados por el uso incorrecto de nuestros servicios o por condiciones fuera de nuestro control.</p>"
                + "<p><strong>Modificaciones:</strong> Nos reservamos el derecho de modificar estos términos y condiciones en cualquier momento. Las modificaciones serán efectivas a partir de su publicación en el sitio web.</p>"
                + "<p>Para más información o si tienes preguntas sobre estos términos, contáctanos a través de <a href='mailto:legal@helpdrom.com'>legal@helpdrom.com</a>.</p></div>";
    }

}
